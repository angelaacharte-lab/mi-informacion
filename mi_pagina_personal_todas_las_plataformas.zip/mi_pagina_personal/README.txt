MI PAGINA WEB PERSONAL - MIRIAN ANGELA ACHARTE SOLIER

Este es UN SOLO PROYECTO web, compatible con:
- GitHub Pages
- Netlify
- Vercel
- Google Firebase Hosting

ARCHIVO PRINCIPAL:
index.html

PARA PUBLICAR:
1. Descomprime este ZIP.
2. Sube la carpeta completa a la plataforma que te solicite tu profesor.
3. En Netlify puedes arrastrar la carpeta al área de publicación.
4. En Vercel importa el repositorio o sube el proyecto.
5. En GitHub Pages sube los archivos a un repositorio y activa Pages desde Settings.
6. En Firebase Hosting usa Firebase CLI: firebase login, firebase init hosting y firebase deploy.
   En la configuración de Firebase, selecciona la carpeta actual como carpeta pública.

No necesitas modificar el diseño para usarlo en cualquiera de las cuatro plataformas.
Puedes cambiar los textos de index.html y agregar una foto si deseas.
